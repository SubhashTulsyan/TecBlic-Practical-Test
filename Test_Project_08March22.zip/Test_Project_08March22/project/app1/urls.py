from django.urls import path
from . import views
from django.views.generic.base import TemplateView
from django.contrib.auth.decorators import login_required
urlpatterns = [
    path('Signup/', views.Signup.as_view(), name='Signup'),
    path('', views.Login_page.as_view(), name='Login_page'),
    path('logout_user/', login_required(views.logout_user,
                                        login_url='/'), name='logout_user'),
    path('dashboard/', login_required(TemplateView.as_view(template_name='app1/dashboard.html'), login_url='/'),
         name='dashboard'),
    # Category
    path('Add_category/', login_required(views.Add_category.as_view(), login_url='/'),
         name='Add_category'),
    path('Update_category/<int:id>/',
         login_required(views.Update_category.as_view(), login_url='/'), name='Update_category'),
    path('Delete_category/<int:id>/',
         login_required(views.Delete_category.as_view(), login_url='/'), name='Delete_category'),
    # Tag
    path('Add_tag/', login_required(views.Add_tag.as_view(),
                                    login_url='/'), name='Add_tag'),
    path('Update_tag/<int:id>/',
         login_required(views.Update_tag.as_view(), login_url='/'), name='Update_tag'),
    path('Delete_tag/<int:id>/',
         login_required(views.Delete_tag.as_view(), login_url='/'), name='Delete_tag'),
    # Product
    path('Add_product/', login_required(views.Add_product.as_view(), login_url='/'),
         name='Add_product'),
    path('Update_product/<int:id>/',
         login_required(views.Update_product.as_view(), login_url='/'), name='Update_product'),
    path('Delete_product/<int:id>/',
         login_required(views.Delete_product.as_view(), login_url='/'), name='Delete_product'),

]
