from django.db import models
from django.contrib.auth.models import User


class Tag(models.Model):
    name = models.CharField(max_length=100)
    created_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='tag_created_by')

    def __str__(self):
        return self.name


class Category(models.Model):
    name = models.CharField(max_length=100)
    parent = models.ForeignKey(
        "self",
        on_delete=models.CASCADE,
        verbose_name="Parent Category",
        null=True,
        blank=True,
        related_name="children",
    )
    created_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='cat_created_by')

    class Meta:
        verbose_name_plural = "Categories"

    def get_categories(self):
        if self.parent is None:
            return self.name
        else:
            return self.parent.get_categories() + " -> " + self.name

    def __str__(self):
        return self.get_categories()


class Product(models.Model):
    name = models.CharField(max_length=100)
    tags = models.ManyToManyField(Tag, related_name="tags")
    image = models.ImageField(upload_to='uploads/')
    categories = models.ManyToManyField(Category, related_name="cats")
    description = models.CharField(max_length=1000)
    created_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='pro_created_by')

    def __str__(self):
        return self.name

    def get_tags(self):
        return ", ".join([tag.name for tag in self.tags.all()])

    def get_cats(self):
        return ",\n".join([cat.name for cat in self.categories.all()])

    def get_image_name(self):
        return self.image.url.split('/')[-1]
