from django.contrib import admin
from .models import Tag, Category, Product


@admin.register(Tag)
class TagModelAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'created_by')


@admin.register(Category)
class CategoryModelAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'parent', 'created_by')


@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'get_tags', 'image',
                    'get_cats', 'description', 'created_by')

    # def get_tags(self, obj):
    #     return ", ".join([o.name for o in obj.tags.all()])

    # def get_cats(self, obj):
    #     return ", ".join([o.name for o in obj.categories.all()])
