from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.generic.base import View, TemplateView, RedirectView
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import authenticate, logout, login

from app1.models import Category, Tag, Product
from .forms import CategoryForm, TagForm, ProductForm, SignupForm
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView
from django.contrib import messages
# Product CRUD start


class Update_product(TemplateView, RedirectView):
    template_name = 'app1/update_product_page.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        print('context: ', context)
        product = Product.objects.get(id=context['id'])
        pf = ProductForm(instance=product)
        context['pf'] = pf
        context['product_id'] = context['id']
        return context

    def post(self, request, *args, **kwargs):
        print('args: ', args)
        print('kwargs: ', kwargs)
        product = Product.objects.get(pk=kwargs['id'])
        pf = ProductForm(request.POST, request.FILES, instance=product)
        if pf.is_valid():
            pf.save()
        return HttpResponseRedirect('/Add_product/')


class Delete_product(RedirectView):
    url = '/Add_product/'

    def get_redirect_url(self, *args, **kwargs):
        #print('Args: ', args)
        print('Kwargs: ', kwargs)
        product = Product(id=kwargs['id'])
        product.delete()
        return super().get_redirect_url(*args, **kwargs)


class Add_product(TemplateView):
    template_name = "app1/product_page.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pf = ProductForm(initial={'created_by': self.request.user})
        products = Product.objects.filter(created_by=self.request.user)
        print('products data: ', products)
        context['pf'] = pf
        context['products'] = products
        return context

    def post(self, request):
        pf = ProductForm(request.POST, request.FILES)
        print('errors:', pf.errors)
        if pf.is_valid():
            pf.save()
            return HttpResponseRedirect('/Add_product/')

# Product CRUD end

# Tag CRUD start


class Update_tag(TemplateView, RedirectView):
    template_name = 'app1/update_tag_page.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        print('context: ', context)
        tag = Tag.objects.get(id=context['id'])
        tf = TagForm(instance=tag)
        context['tf'] = tf
        context['tag_id'] = context['id']
        return context

    def post(self, request, *args, **kwargs):
        print('args: ', args)
        print('kwargs: ', kwargs)
        tag = Tag.objects.get(pk=kwargs['id'])
        tf = TagForm(request.POST, instance=tag)
        if tf.is_valid():
            tf.save()
        return HttpResponseRedirect('/Add_tag/')


class Delete_tag(RedirectView):
    url = '/Add_tag/'

    def get_redirect_url(self, *args, **kwargs):
        #print('Args: ', args)
        print('Kwargs: ', kwargs)
        tag = Tag(id=kwargs['id'])
        tag.delete()
        return super().get_redirect_url(*args, **kwargs)


class Add_tag(TemplateView):
    template_name = "app1/tag_page.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tf = TagForm(initial={'created_by': self.request.user})
        tags = Tag.objects.filter(created_by=self.request.user)
        print('Tags data: ', tags)
        context['tf'] = tf
        context['tags'] = tags
        return context

    def post(self, request):
        tf = TagForm(request.POST)
        if tf.is_valid():
            tf.save()
            return HttpResponseRedirect('/Add_tag/')

# Tag CRUD end


# Category CRUD start
class Update_category(TemplateView, RedirectView):
    template_name = 'app1/update_category_page.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        print('context: ', context)
        cat = Category.objects.get(id=context['id'])
        cf = CategoryForm(instance=cat)
        context['cf'] = cf
        context['cat_id'] = context['id']
        return context

    def post(self, request, *args, **kwargs):
        print('args: ', args)
        print('kwargs: ', kwargs)
        cat = Category.objects.get(pk=kwargs['id'])
        cf = CategoryForm(request.POST, instance=cat)
        if cf.is_valid():
            cf.save()
        return HttpResponseRedirect('/Add_category/')


class Delete_category(RedirectView):
    url = '/Add_category/'

    def get_redirect_url(self, *args, **kwargs):
        #print('Args: ', args)
        print('Kwargs: ', kwargs)
        cat = Category(id=kwargs['id'])
        cat.delete()
        return super().get_redirect_url(*args, **kwargs)


class Add_category(TemplateView):
    template_name = "app1/category_page.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cf = CategoryForm(initial={'created_by': self.request.user})
        cats = Category.objects.filter(created_by=self.request.user)
        print('cats data: ', cats)
        context['cf'] = cf
        context['cats'] = cats
        return context

    def post(self, request):
        cf = CategoryForm(request.POST)
        if cf.is_valid():
            cf.save()
            return HttpResponseRedirect('/Add_category/')

# Category CRUD end


class Login_page(View):
    template_name = "app1/login_page.html"

    def get(self, request):
        if request.user.is_authenticated:
            return HttpResponseRedirect('/dashboard/')

        af = AuthenticationForm()
        data = {"af": af}
        return render(request, self.template_name, context=data)

    def post(self, request):
        print('in post')
        af_b = AuthenticationForm(request=request, data=request.POST)
        print('af_b errors: ', af_b.errors)
        if af_b.is_valid():
            print('is valid')
            uname = af_b.cleaned_data['username']
            print('uname: ', uname)
            password = af_b.cleaned_data['password']
            print('password: ', password)
            user = authenticate(request, username=uname, password=password)
            if user is not None:
                login(request, user)
                return render(request, 'app1/dashboard.html')
            else:
                return HttpResponse('<h1> User credential is incorrect. </h1>')
        else:
            return HttpResponse(af_b.errors.as_text())


def logout_user(request):
    logout(request)
    return HttpResponseRedirect('/')


class Signup(TemplateView):
    template_name = "app1/signup.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        sf = SignupForm()
        context['sf'] = sf
        return context

    def post(self, request):
        sf = SignupForm(request.POST)
        if sf.is_valid():
            sf.save()
            messages.add_message(request, messages.INFO,
                                 'User Created Successfully !!')
            return HttpResponseRedirect('/')
